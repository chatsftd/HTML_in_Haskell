HTML_in_Haskell
===============

Let ghc do the HTML5 validation
